<html>
<head>
<title>cancel booking</title>
<style>
	h1{
    padding-top: 17%;
    color: red;
    font-size:x-large;
    font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
}
body{
    background: url("bgimg6.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    align-content: center;
}
	</style>
</head>
<body>
<?php
//including the database connection file
include_once("config.php");
$name = $_POST['name'];
$mobno = $_POST['mobno'];
$city = $_POST['city'];
$branch = $_POST['branch'];
$services = $_POST['services'];
$date = $_POST['date'];
$slot = $_POST['slot'];


//insert data to database
$ins_query="DELETE FROM `appointments` WHERE `Name`='$name'";
$result = mysqli_query($mysqli,$ins_query);

//display success message

?>
<center><h1>BOOKING CANCELLED SUCCESSFULLY !!!</h1></center>

</body>
</html>