<html>
<head>
<title>Add Employee Details</title>
<style>
	h1{
    padding-top: 20%;
    color: green;
    font-size:x-large;
    font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
}
body{
    background: url("bgimg6.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    align-content: center;
}
	</style>
</head>
<body>
<?php
//including the database connection file
include_once("config.php");
$name = $_POST['name'];
$mobno = $_POST['mobno'];
$email = $_POST['email'];
$city = $_POST['city'];
$branch = $_POST['branch'];
$services = $_POST['services'];
$date = $_POST['date'];
$slot = $_POST['slot'];


//insert data to database
$ins_query="INSERT INTO `appointments`(`Name`, `Email`, `PhNo`, `Branch`, `Services`, `Date`, `Slot`) VALUES('$name','$email',$mobno,'$branch','$services','$date','$slot') ";
$result = mysqli_query($mysqli,$ins_query);

//display success message

?>
<center><h1>APPOINTMENT BOOKED SUCCESSFULLY !!!</h1></center>
<center><h2 style="color:green">WE WILL MEET SOON:)</h2></center>
</body>
</html>