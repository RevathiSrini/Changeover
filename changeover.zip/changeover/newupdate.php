<html>
<head>
<title>update service availability</title>
<style>
h1{
    padding-top: 20%;
    color: green;
    font-size:x-large;
    font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
}
body{
    background: url("bgimg6.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    align-content: center;
}
</style>
</head>
<body>
<?php
// including the database connection file
include_once("config.php");
$ServiceName = $_POST['ServiceName'];
$Availability = $_POST['Availability'];
//updating the table
$result = mysqli_query($mysqli, "UPDATE `services` SET Availability='$Availability' WHERE ServiceName='$ServiceName'");

?>
<center><h1>AVAILABILITY UPDATED SUCCESSFULLY</h1></center>
</body>
</html>
