<?php
//including the database connection file
include_once("config.php");
$sql = " SELECT * FROM services ";
$result = $mysqli->query($sql);
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <title>GFG User Details</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
    	body{
            background: url("bgimg6.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            color: white;
        }
        table {
            margin: 0 auto;
            font-size: large;

        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
         table,th, td {
  border: 1px solid white;
  border-collapse: collapse;
}
th, td {
  padding-top: 10px;
  padding-bottom: 20px;
  padding-left: 20px;
  padding-right: 20px;
}
th{
    background-color: grey;
    color: black;
}

    </style>
</head>
 
<body>
    <section>
        <h1>Services Available Currently</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>Service name</th>
                <th>Current Availability</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS -->
            <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $rows['ServiceName'];?></td>
                <td><?php echo $rows['Availability'];?></td>
            </tr>
            </tr>
            <?php
                }
            ?>
        </table>
    </section>
</body>
 
</html>
