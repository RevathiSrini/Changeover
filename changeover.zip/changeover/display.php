<?php
//including the database connection file
include_once("config.php");
$sql = " SELECT * FROM appointments ";
$result = $mysqli->query($sql);
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <title>GFG User Details</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
    	body{
            background: url("bgimg6.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            color: white;
        }
        table {
            margin: 0 auto;
            font-size: large;

        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
         table,th, td {
  border: 1px solid white;
  border-collapse: collapse;
}
th, td {
  padding-top: 10px;
  padding-bottom: 20px;
  padding-left: 20px;
  padding-right: 20px;
}

    </style>
</head>
 
<body>
    <div align="center">
    <section>
        <h1>APPOINTMENTS BOOKED</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr style="background-color: grey;">
                <th>Firstname</th>
                <th>Email-id</th>
                <th>Contact No</th>
                <th>Branch Choosen</th>
                <th>Services needed</th>
                <th>Date</th>
                 <th>Slot selected</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS -->
            <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $rows['Name'];?></td>
                <td><?php echo $rows['Email'];?></td>
                <td><?php echo $rows['PhNo'];?></td>
                <td><?php echo $rows['Branch'];?></td>
                <td><?php echo $rows['Services'];?></td>
                <td><?php echo $rows['Date'];?></td>
                <td><?php echo $rows['Slot'];?></td>
            </tr>
            </tr>
            <?php
                }
            ?>
        </table>
    </section>
    <br><br>
    <div align="center">
    <a href="newadmin1.html" style="color:limegreen; align-content: center; font-size: 15px;" >BACK</a></div>
    
</body>
 
</html>

