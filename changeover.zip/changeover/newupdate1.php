<html>
<head>
<title>update service availability</title>
</head>
<body>
<?php
// including the database connection file
include_once("config.php");
if(isset($_POST['update']))
{
$ServiceName = $_POST['ServiceName'];
$Availability = $_POST['Availability'];
//updating the table
$result = mysqli_query($mysqli, "UPDATE `services` SET Availability='$Availability' WHERE ServiceName='$ServiceName'");
echo "updated successfully";
}
?>
